# views.py
from django.shortcuts import render
from .nlp_utils import process_text, tfidf, bow

def home(request):
    analysis_result = []
    
    if request.method == "POST":
        input_text = request.POST.get("inputText", "").strip()
        process_type = request.POST.get("process_type", "none")

        if not input_text:
            return render(request, "home/index.html", {"analysis_result": []})

        result = process_text(input_text)

        
        if process_type == "tokenize":
            analysis_result.append({"title": "Tokens", "output": result["tokens"]})
        elif process_type == "lower":
            analysis_result.append({"title": "Lowercase", "output": result["lowercase"]})
        elif process_type == "stopwords":
            analysis_result.append({"title": "After Stopword Removal", "output": result["tokens_no_stop"]})
        elif process_type == "stem":
            analysis_result.append({"title": "Stemming", "output": result["stemmed"]})
        elif process_type == "lemma":
            analysis_result.append({"title": "Lemmatization", "output": result["lemmatized"]})
        elif process_type == "pos":
            analysis_result.append({"title": "POS Tagging", "output": result["pos_tags"]})
        elif process_type == "bow":
            bow_result = bow(result["tokens_no_stop"])
            analysis_result.append({"title": "Bag of Words", "output": bow_result})
        elif process_type == "tfidf":
            tfidf_result = tfidf(result["tokens_no_stop"])
            analysis_result.append({"title": "TF-IDF Scores", "output": tfidf_result})
        else:
           
            analysis_result = []

    return render(request, "index.html", {"analysis_result": analysis_result})



def base(request):
    return render(request, "base.html")