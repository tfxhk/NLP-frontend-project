import nltk
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
from nltk.stem import PorterStemmer, WordNetLemmatizer
from nltk import pos_tag
import string

# Download required resources (run once)
nltk.download('punkt')
nltk.download('stopwords')
nltk.download('averaged_perceptron_tagger')
nltk.download('wordnet')

# Input raw text
raw_text = "NLTK is a leading platform for building Python programs to work with human language data. It includes libraries for classification, tokenization, stemming, tagging, and more in 2025!" (it's a sample but i want to take it as user input so make changes accordingly not for this corpus)

print("Original Text:\n", raw_text)

# 1. Lowercasing
text_lower = raw_text.lower()

# 2. Remove punctuation and numbers
text_clean = ''.join([char for char in text_lower if char.isalpha() or char.isspace()])

# 3. Tokenization
tokens = word_tokenize(text_clean)

# 4. Stopword Removal
stop_words = set(stopwords.words('english'))
tokens_no_stop = [word for word in tokens if word not in stop_words]

# 5. Stemming
stemmer = PorterStemmer()
stemmed_words = [stemmer.stem(word) for word in tokens_no_stop]

# 6. Lemmatization
lemmatizer = WordNetLemmatizer()
lemmatized_words = [lemmatizer.lemmatize(word) for word in tokens_no_stop]

# 7. POS Tagging (using tokens after cleaning but before stemming/lemmatization)
pos_tags = pos_tag(tokens_no_stop)

# Display Results
print("\nLowercased & Cleaned Text:\n", text_clean)
print("\nTokens (after cleaning):\n", tokens_no_stop)
print("\nStemmed Words:\n", stemmed_words)
print("\nLemmatized Words:\n", lemmatized_words)
print("\nPOS Tags:\n", pos_tags)




# bag of words
!pip install scikit-learn
from sklearn.feature_extraction.text import CountVectorizer
import pandas as pd

# Given corpus
corpus = [
"I am loving the NLP class, but sometimes it feels confusing!!!",
"NLP is a fascinating field — it deals with text, speech, and language understanding."
]

print("Original Corpus:")
for i, sentence in enumerate(corpus, 1):
print(f"{i}: {sentence}")

# ---------- Method 1: Using CountVectorizer ----------
# Convert text to lowercase automatically and remove punctuation
vectorizer = CountVectorizer()

# Fit and transform
X = vectorizer.fit_transform(corpus)

# Get vocabulary
vocab = vectorizer.get_feature_names_out()
print("\nVocabulary:\n", vocab)

# Convert to DataFrame for better view
bow_df = pd.DataFrame(X.toarray(), columns=vocab)
print("\nBag of Words Representation:")
print(bow_df)

# ---------- Method 2: Manually create vocabulary (optional) ----------
import re

# Clean and split each sentence manually
tokens_all = []
for sentence in corpus:
clean_sentence = re.sub(r'[^a-zA-Z\s]', '', sentence) # remove punctuation/numbers
clean_sentence = clean_sentence.lower()
tokens = clean_sentence.split()
tokens_all.extend(tokens)

# Unique words (vocabulary)
manual_vocab = sorted(set(tokens_all))
print("\nManual Vocabulary:\n", manual_vocab)



# TF-IDF
from sklearn.feature_extraction.text import TfidfVectorizer

docs = [
"I like apples",
"I like oranges",
"Apples and oranges are fruits"
]

vectorizer = TfidfVectorizer()
tfidf_matrix = vectorizer.fit_transform(docs)

print(vectorizer.get_feature_names_out()) # vocabulary
print(tfidf_matrix.toarray()) # TF-IDF scores

if __name__ == "__main__":
    sample = input("Enter text: ")
    print("Cleaned text:", clean_text(sample))