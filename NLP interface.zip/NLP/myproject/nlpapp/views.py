from django.shortcuts import render
from . import nlp_code  # import NLP logic

def home(request):
    result = ""
    if request.method == "POST":
        user_text = request.POST.get("user_text", "")
        result = nlp_code.process_text(user_text)  # process text
    return render(request, "index.html", {"result": result})

