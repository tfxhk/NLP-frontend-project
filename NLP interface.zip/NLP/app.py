from flask import Flask, request, jsonify, render_template
import nltk
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
from nltk.stem import PorterStemmer, WordNetLemmatizer
from nltk import pos_tag
from sklearn.feature_extraction.text import CountVectorizer, TfidfVectorizer

nltk.download('punkt')
nltk.download('stopwords')
nltk.download('averaged_perceptron_tagger')
nltk.download('wordnet')

app = Flask(__name__)

# Serve the HTML frontend
@app.route("/")
def home():
    return render_template("index.html")


# NLP API endpoint
@app.route("/analyze", methods=["POST"])
def analyze():
    data = request.get_json()
    raw_text = data.get("text", "")

    if not raw_text.strip():
        return jsonify({"error": "No text provided"}), 400

    # 1. Lowercase
    text_lower = raw_text.lower()

    # 2. Remove punctuation/numbers
    text_clean = ''.join([c for c in text_lower if c.isalpha() or c.isspace()])

    # 3. Tokenization
    tokens = word_tokenize(text_clean)

    # 4. Stopword Removal
    stop_words = set(stopwords.words('english'))
    tokens_no_stop = [w for w in tokens if w not in stop_words]

    # 5. Stemming
    stemmer = PorterStemmer()
    stemmed = [stemmer.stem(w) for w in tokens_no_stop]

    # 6. Lemmatization
    lemmatizer = WordNetLemmatizer()
    lemmatized = [lemmatizer.lemmatize(w) for w in tokens_no_stop]

    # 7. POS Tagging
    pos_tags = pos_tag(tokens_no_stop)

    # Bag of Words
    vectorizer = CountVectorizer()
    bow = vectorizer.fit_transform([raw_text])
    bow_vocab = vectorizer.get_feature_names_out().tolist()
    bow_array = bow.toarray().tolist()

    # TF-IDF
    tfidf = TfidfVectorizer()
    tfidf_matrix = tfidf.fit_transform([raw_text])
    tfidf_vocab = tfidf.get_feature_names_out().tolist()
    tfidf_array = tfidf_matrix.toarray().tolist()

    return jsonify({
        "original_text": raw_text,
        "cleaned_text": text_clean,
        "tokens": tokens,
        "no_stopwords": tokens_no_stop,
        "stemmed": stemmed,
        "lemmatized": lemmatized,
        "pos_tags": pos_tags,
        "bow": {"vocab": bow_vocab, "matrix": bow_array},
        "tfidf": {"vocab": tfidf_vocab, "matrix": tfidf_array}
    })


if __name__ == "__main__":
    app.run(debug=True)
