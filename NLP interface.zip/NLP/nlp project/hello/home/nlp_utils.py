import nltk
nltk.data.path.append("/Users/abdulmanan/nltk_data")

from nltk.corpus import stopwords
from nltk.stem import PorterStemmer, WordNetLemmatizer
from nltk import pos_tag
from nltk.tokenize import TreebankWordTokenizer
from collections import Counter
import numpy as np

# Downloads (run once)
nltk.download('stopwords')
nltk.download('wordnet')
nltk.download('averaged_perceptron_tagger')

# Initialize tools
tokenizer = TreebankWordTokenizer()
stemmer = PorterStemmer()
lemmatizer = WordNetLemmatizer()
stop_words = set(stopwords.words('english'))

def process_text(raw_text):
    text_lower = raw_text.lower()
    tokens = tokenizer.tokenize(text_lower)
    tokens_no_stop = [t for t in tokens if t.isalpha() and t not in stop_words]
    stemmed = [stemmer.stem(t) for t in tokens_no_stop]
    lemmatized = [lemmatizer.lemmatize(t) for t in tokens_no_stop]
    pos_tags = pos_tag(tokens_no_stop)

    return {
        "original": raw_text,
        "lowercase": text_lower,
        "tokens": tokens,
        "tokens_no_stop": tokens_no_stop,
        "stemmed": stemmed,
        "lemmatized": lemmatized,
        "pos_tags": pos_tags
    }

def bow(tokens):
    """Bag of Words"""
    return dict(Counter(tokens))

def tfidf(tokens):
    """Simple TF-IDF-like"""
    counts = Counter(tokens)
    norm = np.sqrt(sum([c**2 for c in counts.values()]))
    tfidf_scores = {word: round(count / norm, 4) for word, count in counts.items()}
    return tfidf_scores